import useWhaleFeed from "./hooks/useWhaleFeed";

import Header from "./components/Header";
import StatsGrid from "./components/StatsGrid";
import PriceChart from "./components/PriceChart";
import TradesTable from "./components/TradesTable";
import WhaleAlerts from "./components/WhaleAlerts";
import WhaleAlertToast from "./components/WhaleAlertToast";
import SystemStatus from "./components/SystemStatus";
import HowItWorks from "./components/HowItWorks";
import Footer from "./components/Footer";

function App() {
  const {
    isConnected,
    feedConnected,
    trades,
    whaleAlerts,
    whaleCount,
    latestAlert,
    dismissLatestAlert,
    coinData,
    coinError,
  } = useWhaleFeed();

  const totalVolume = trades.reduce((sum, t) => sum + parseFloat(t.q || 0), 0);

  return (
    <div className="mx-auto min-h-screen max-w-7xl px-4 sm:px-6 lg:px-8">
      <WhaleAlertToast alert={latestAlert} onDismiss={dismissLatestAlert} />

      <Header isConnected={isConnected} feedConnected={feedConnected} />

      <StatsGrid
        coinData={coinData}
        totalVolume={totalVolume}
        tradeCount={trades.length}
        whaleCount={whaleCount}
      />

      <main className="mt-8 grid grid-cols-1 gap-6 pb-6 lg:grid-cols-[2fr_1fr]">
        <div className="flex flex-col gap-6">
          <PriceChart trades={trades} />
          <TradesTable trades={trades} />
        </div>

        <div className="flex flex-col gap-6">
          <WhaleAlerts alerts={whaleAlerts} />
          <SystemStatus
            isConnected={isConnected}
            feedConnected={feedConnected}
            coinData={coinData}
            coinError={coinError}
          />
          <HowItWorks />
        </div>
      </main>

      <Footer />
    </div>
  );
}

export default App;
