import { Wifi, WifiOff } from "lucide-react";

export default function ConnectionBadge({ connected, label }) {
  return (
    <div
      className={`flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-medium ${
        connected
          ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-300"
          : "border-red-500/30 bg-red-500/10 text-red-300"
      }`}
    >
      <span className="relative flex h-2 w-2">
        {connected && (
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
        )}
        <span
          className={`relative inline-flex h-2 w-2 rounded-full ${
            connected ? "bg-emerald-400" : "bg-red-400"
          }`}
        />
      </span>
      {connected ? (label ?? "Connected") : "Disconnected"}
      {connected ? (
        <Wifi size={13} strokeWidth={2.25} />
      ) : (
        <WifiOff size={13} strokeWidth={2.25} />
      )}
    </div>
  );
}
