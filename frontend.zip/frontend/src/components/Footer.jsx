import config from "../config";

export default function Footer() {
  return (
    <footer className="border-t border-white/5 py-6 text-center">
      <p className="text-sm text-slate-400">
        🚀 {config.appName} v1.0 · Real-time institutional trade detection
      </p>
      <p className="mt-1 text-xs text-slate-600">
        Data: Binance WebSocket &amp; CoinGecko API · Stack: Node.js, Socket.io, React,
        Chart.js
      </p>
    </footer>
  );
}
