import config from "../config";
import ConnectionBadge from "./ConnectionBadge";
import LiveClock from "./LiveClock";

export default function Header({ isConnected, feedConnected }) {
  return (
    <header className="flex flex-wrap items-center justify-between gap-4 py-6">
      <div className="flex items-center gap-4">
        <div className="relative flex h-12 w-12 items-center justify-center">
          <span className="absolute inline-flex h-full w-full animate-sonar rounded-full bg-cyan-glow/40" />
          <span className="relative flex h-12 w-12 items-center justify-center rounded-full bg-abyss-700 text-2xl shadow-glow">
            🐋
          </span>
        </div>
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-white sm:text-3xl">
            {config.appName}
          </h1>
          <p className="text-sm text-slate-400">
            Live {config.coinSymbol} institutional trade detection
          </p>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <LiveClock />
        <div className="hidden h-8 w-px bg-white/10 sm:block" />
        <div className="flex flex-col items-end gap-2">
          <ConnectionBadge connected={isConnected} label="Server" />
          <ConnectionBadge connected={feedConnected} label="Binance feed" />
        </div>
      </div>
    </header>
  );
}
