import config from "../config";

const items = [
  { color: "bg-cyan-glow", text: `Real-time ${config.coinSymbol} trades via Binance` },
  {
    color: "bg-gold-glow",
    text: `Alerts for trades ≥ $${config.whaleThresholdUsd.toLocaleString()}`,
  },
  { color: "bg-emerald-400", text: `${config.chartWindowSize}-trade rolling price chart` },
  { color: "bg-purple-400", text: "Metadata from the CoinGecko API" },
];

export default function HowItWorks() {
  return (
    <div className="panel p-5">
      <h2 className="panel-title mb-4">How it works</h2>
      <ul className="flex flex-col gap-3">
        {items.map((item) => (
          <li key={item.text} className="flex items-center gap-3 text-sm text-slate-300">
            <span className={`h-1.5 w-1.5 shrink-0 rounded-full ${item.color}`} />
            {item.text}
          </li>
        ))}
      </ul>
    </div>
  );
}
