import { useEffect, useState } from "react";

export default function LiveClock() {
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="text-right font-mono leading-tight">
      <div className="text-sm text-slate-200">{now.toLocaleTimeString()}</div>
      <div className="text-[11px] text-slate-500">{now.toLocaleDateString()}</div>
    </div>
  );
}
