import { useMemo } from "react";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import config from "../config";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

export default function PriceChart({ trades }) {
  const chartData = useMemo(() => {
    const windowed = trades.slice(-config.chartWindowSize);
    return {
      labels: windowed.map((t) => new Date(t.T).toLocaleTimeString()),
      datasets: [
        {
          label: `Price (${config.coinSymbol})`,
          data: windowed.map((t) => parseFloat(t.p)),
          borderColor: "#22d3ee",
          backgroundColor: "rgba(34, 211, 238, 0.12)",
          pointRadius: 0,
          pointHoverRadius: 4,
          fill: true,
          tension: 0.35,
          borderWidth: 2,
        },
      ],
    };
  }, [trades]);

  const options = useMemo(
    () => ({
      responsive: true,
      maintainAspectRatio: false,
      animation: { duration: 250 },
      plugins: {
        legend: { display: false },
        title: {
          display: true,
          text: `${config.coinSymbol} price · last ${config.chartWindowSize} trades`,
          color: "#94a3b8",
          font: { family: "'Space Grotesk', sans-serif", size: 13, weight: "600" },
          padding: { bottom: 16 },
        },
        tooltip: {
          backgroundColor: "#0c1424",
          borderColor: "rgba(34, 211, 238, 0.3)",
          borderWidth: 1,
          titleColor: "#e2e8f0",
          bodyColor: "#22d3ee",
          padding: 10,
        },
      },
      scales: {
        x: {
          grid: { color: "rgba(255,255,255,0.04)" },
          ticks: { color: "#64748b", maxTicksLimit: 8, font: { size: 10 } },
        },
        y: {
          beginAtZero: false,
          grid: { color: "rgba(255,255,255,0.06)" },
          ticks: {
            color: "#64748b",
            font: { size: 10, family: "'JetBrains Mono', monospace" },
            callback: (val) => `$${Number(val).toLocaleString()}`,
          },
        },
      },
    }),
    []
  );

  return (
    <div className="panel p-5">
      <div className="h-[360px]">
        {trades.length > 0 ? (
          <Line data={chartData} options={options} />
        ) : (
          <div className="flex h-full flex-col items-center justify-center gap-2 text-slate-500">
            <span className="animate-pulse-slow text-3xl">📡</span>
            <p className="text-sm">Waiting for the first trade to arrive…</p>
          </div>
        )}
      </div>
    </div>
  );
}
