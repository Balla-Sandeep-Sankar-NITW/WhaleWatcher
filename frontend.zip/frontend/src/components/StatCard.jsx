export default function StatCard({ icon: Icon, label, value, sub, accent = "cyan" }) {
  const accentClasses = {
    cyan: "text-cyan-glow bg-cyan-glow/10",
    gold: "text-gold-glow bg-gold-glow/10",
    emerald: "text-emerald-400 bg-emerald-400/10",
    red: "text-red-400 bg-red-400/10",
  };

  return (
    <div className="panel flex items-start justify-between gap-3 p-5 transition-transform hover:-translate-y-0.5">
      <div className="min-w-0">
        <div className="panel-title">{label}</div>
        <div className="mt-2 truncate font-mono text-2xl font-semibold text-white">
          {value}
        </div>
        {sub && <div className="mt-1 text-xs text-slate-500">{sub}</div>}
      </div>
      {Icon && (
        <div className={`rounded-xl p-2.5 ${accentClasses[accent]}`}>
          <Icon size={20} strokeWidth={2} />
        </div>
      )}
    </div>
  );
}
