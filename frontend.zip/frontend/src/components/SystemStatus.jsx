function StatusRow({ label, value, tone }) {
  const toneClasses = {
    green: "bg-emerald-500/15 text-emerald-300",
    yellow: "bg-yellow-500/15 text-yellow-300",
    red: "bg-red-500/15 text-red-300",
    blue: "bg-cyan-glow/15 text-cyan-glow",
  };

  return (
    <div className="flex items-center justify-between border-b border-white/5 pb-3.5 last:border-0 last:pb-0">
      <span className="text-sm text-slate-300">{label}</span>
      <span className={`rounded-full px-3 py-1 text-xs font-semibold ${toneClasses[tone]}`}>
        {value}
      </span>
    </div>
  );
}

export default function SystemStatus({ isConnected, feedConnected, coinData, coinError }) {
  return (
    <div className="panel p-5">
      <h2 className="panel-title mb-4">System status</h2>
      <div className="flex flex-col gap-3.5">
        <StatusRow
          label="Server connection"
          value={isConnected ? "Connected" : "Disconnected"}
          tone={isConnected ? "green" : "red"}
        />
        <StatusRow
          label="Binance WebSocket"
          value={feedConnected ? "Streaming" : "Reconnecting…"}
          tone={feedConnected ? "green" : "yellow"}
        />
        <StatusRow
          label="CoinGecko API"
          value={coinError ? "Error" : coinData ? "Connected" : "Connecting…"}
          tone={coinError ? "red" : coinData ? "green" : "yellow"}
        />
        <StatusRow label="Data pipeline" value="Active" tone="blue" />
      </div>
    </div>
  );
}
