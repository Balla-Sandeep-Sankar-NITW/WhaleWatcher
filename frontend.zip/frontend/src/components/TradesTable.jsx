import { useMemo } from "react";
import { ArrowDownRight, ArrowUpRight } from "lucide-react";

export default function TradesTable({ trades }) {
  const rows = useMemo(() => trades.slice().reverse().slice(0, 12), [trades]);

  return (
    <div className="panel p-5">
      <h2 className="panel-title mb-4">Recent trades</h2>

      {rows.length === 0 ? (
        <p className="py-8 text-center text-sm text-slate-500">No trades yet.</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="text-xs uppercase tracking-wide text-slate-500">
                <th className="pb-3 pr-4 font-medium">Time</th>
                <th className="pb-3 pr-4 font-medium">Price</th>
                <th className="pb-3 pr-4 font-medium">Amount</th>
                <th className="pb-3 pr-4 font-medium">Value</th>
                <th className="pb-3 font-medium">Side</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((trade, index) => {
                const price = parseFloat(trade.p);
                const qty = parseFloat(trade.q);
                const value = price * qty;
                const isSell = Boolean(trade.m);

                return (
                  <tr
                    key={`${trade.T}-${index}`}
                    className={`border-t border-white/5 font-mono ${
                      trade.isWhale ? "bg-gold-glow/5" : ""
                    }`}
                  >
                    <td className="py-2.5 pr-4 text-slate-400">
                      {new Date(trade.T).toLocaleTimeString()}
                    </td>
                    <td className="py-2.5 pr-4 text-slate-200">
                      ${price.toFixed(2)}
                    </td>
                    <td className="py-2.5 pr-4 text-slate-200">
                      {qty.toFixed(4)} BTC
                    </td>
                    <td
                      className={`py-2.5 pr-4 ${
                        trade.isWhale ? "font-semibold text-gold-glow" : "text-slate-200"
                      }`}
                    >
                      ${value.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                    </td>
                    <td className="py-2.5">
                      <span
                        className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-xs font-semibold ${
                          isSell
                            ? "bg-red-500/15 text-red-300"
                            : "bg-emerald-500/15 text-emerald-300"
                        }`}
                      >
                        {isSell ? (
                          <ArrowDownRight size={12} />
                        ) : (
                          <ArrowUpRight size={12} />
                        )}
                        {isSell ? "SELL" : "BUY"}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
