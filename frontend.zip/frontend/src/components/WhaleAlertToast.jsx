import { X } from "lucide-react";

export default function WhaleAlertToast({ alert, onDismiss }) {
  if (!alert) return null;

  return (
    <div className="fixed right-4 top-4 z-50 w-[min(360px,calc(100vw-2rem))] animate-slide-in">
      <div className="flex items-start gap-3 rounded-2xl border border-gold-glow/40 bg-abyss-800/95 p-4 shadow-glow-gold backdrop-blur">
        <span className="animate-float text-3xl leading-none">🐋</span>
        <div className="min-w-0 flex-1">
          <div className="flex items-center justify-between gap-2">
            <h3 className="font-display text-sm font-bold text-gold-glow">
              Whale alert
            </h3>
            <button
              type="button"
              onClick={onDismiss}
              aria-label="Dismiss whale alert"
              className="rounded-md p-1 text-slate-500 transition-colors hover:bg-white/5 hover:text-slate-300"
            >
              <X size={14} />
            </button>
          </div>
          <p className="mt-1 font-mono text-lg font-semibold text-white">
            ${alert.value.toLocaleString(undefined, { maximumFractionDigits: 0 })}
          </p>
          <p className="mt-0.5 text-xs text-slate-400">
            {alert.quantity.toFixed(4)} BTC {alert.side} @ ${alert.price.toFixed(2)}
          </p>
        </div>
      </div>
    </div>
  );
}
