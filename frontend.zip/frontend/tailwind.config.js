/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        abyss: {
          950: "#040810",
          900: "#070d18",
          800: "#0c1424",
          700: "#121c30",
          600: "#1a2740",
        },
        cyan: {
          glow: "#22d3ee",
        },
        gold: {
          glow: "#f0b429",
        },
      },
      fontFamily: {
        display: ["'Space Grotesk'", "sans-serif"],
        body: ["'Inter'", "sans-serif"],
        mono: ["'JetBrains Mono'", "monospace"],
      },
      boxShadow: {
        glow: "0 0 0 1px rgba(34, 211, 238, 0.15), 0 0 24px rgba(34, 211, 238, 0.08)",
        "glow-gold":
          "0 0 0 1px rgba(240, 180, 41, 0.25), 0 0 32px rgba(240, 180, 41, 0.15)",
      },
      animation: {
        sonar: "sonar 2.4s ease-out infinite",
        "pulse-slow": "pulse 2.4s cubic-bezier(0.4, 0, 0.6, 1) infinite",
        float: "float 3s ease-in-out infinite",
        "slide-in": "slide-in 0.35s ease-out",
        "fade-in": "fade-in 0.4s ease-out",
      },
      keyframes: {
        sonar: {
          "0%": { transform: "scale(0.6)", opacity: "0.7" },
          "100%": { transform: "scale(2.4)", opacity: "0" },
        },
        float: {
          "0%, 100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-10px)" },
        },
        "slide-in": {
          "0%": { transform: "translateX(16px)", opacity: "0" },
          "100%": { transform: "translateX(0)", opacity: "1" },
        },
        "fade-in": {
          "0%": { opacity: "0" },
          "100%": { opacity: "1" },
        },
      },
    },
  },
  plugins: [],
};
